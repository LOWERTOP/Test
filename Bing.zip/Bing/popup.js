// popup.js

document.addEventListener("DOMContentLoaded", () => {
  // Get UI elements
  const wordCountEl = document.getElementById("wordCount");
  const nextSearchEl = document.getElementById("nextSearch");
  const statusEl = document.getElementById("status");
  const customInput = document.getElementById("customWord");
  const togglePauseBtn = document.getElementById("togglePause");
  const intervalSlider = document.getElementById("intervalSlider");
  const intervalValueLabel = document.getElementById("intervalValueLabel");

  // Mapping from level to label (must match background.js)
  const intervalLabels = [
    "1-3 分钟", "2-4 分钟", "3-5 分钟", "4-6 分钟",
    "5-7 分钟", "6-8 分钟", "7-9 分钟"
  ];

  let refreshInterval = null;

  function updateIntervalLabel(level) {
      const numericLevel = parseInt(level, 10);
      if (numericLevel >= 0 && numericLevel < intervalLabels.length) {
          intervalValueLabel.textContent = intervalLabels[numericLevel];
      } else {
          intervalValueLabel.textContent = "未知"; // Fallback
      }
  }

  function refreshStatus() {
    chrome.runtime.sendMessage({ action: "getStatus" }, res => {
      if (chrome.runtime.lastError) {
        console.error("Error communicating with background:", chrome.runtime.lastError.message);
        statusEl.textContent = "错误"; statusEl.style.color = "black";
        nextSearchEl.textContent = "N/A"; wordCountEl.textContent = "N/A";
        togglePauseBtn.textContent = "状态错误"; togglePauseBtn.disabled = true;
        intervalSlider.disabled = true;
        if (refreshInterval) clearInterval(refreshInterval);
        return;
      }

      // Enable controls if they were disabled
      togglePauseBtn.disabled = false;
      intervalSlider.disabled = false;

      // Update general status
      wordCountEl.textContent = res.wordCount;
      nextSearchEl.textContent = res.isPaused ? "已暂停" : (res.countdown > 0 ? `${res.countdown} 秒` : "即将开始...");

      if (res.isPaused) {
        statusEl.textContent = "已暂停"; statusEl.style.color = "red";
        togglePauseBtn.textContent = "恢复自动搜索";
      } else {
        statusEl.textContent = "运行中"; statusEl.style.color = "green";
        togglePauseBtn.textContent = "暂停自动搜索";
      }

      // Update interval slider and label (only if value differs)
      const currentSliderValue = intervalSlider.value;
      const storedLevel = res.intervalLevel;
      if (currentSliderValue != storedLevel) {
            intervalSlider.value = storedLevel; // Update slider position
      }
      updateIntervalLabel(storedLevel); // Update label text
    });
  }

  // --- Event Listeners ---

  intervalSlider.addEventListener("input", () => {
      // Update label immediately on slide
      updateIntervalLabel(intervalSlider.value);
  });

  intervalSlider.addEventListener("change", () => {
      // Send message to background only when slider value is finalized
      const newLevel = parseInt(intervalSlider.value, 10);
      console.log("Slider changed, sending level:", newLevel);
      chrome.runtime.sendMessage({ action: "setIntervalLevel", level: newLevel }, response => {
          if (chrome.runtime.lastError) {
              console.error(chrome.runtime.lastError.message);
          } else {
              console.log("Set interval level response:", response);
          }
          // Refresh status to confirm change and potentially update countdown
          refreshStatus();
      });
  });

  document.getElementById("searchNowBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "triggerImmediate" }, response => {
        if (chrome.runtime.lastError) console.error(chrome.runtime.lastError.message);
        refreshStatus();
    });
  });

  document.getElementById("resetBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "resetWords" }, response => {
        if (chrome.runtime.lastError) console.error(chrome.runtime.lastError.message);
        refreshStatus();
    });
  });

  document.getElementById("manualSearchBtn").addEventListener("click", () => {
    const word = customInput.value.trim();
    if (word) {
      chrome.runtime.sendMessage({ action: "manualSearch", word }, response => {
          if (chrome.runtime.lastError) console.error(chrome.runtime.lastError.message);
          customInput.value = '';
          refreshStatus(); // Refresh status which might show new countdown if timer was reset
      });
    } else {
      customInput.placeholder = "请输入要搜索的词！";
    }
  });

  customInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      document.getElementById("manualSearchBtn").click();
    }
  });

  togglePauseBtn.addEventListener("click", () => {
     togglePauseBtn.disabled = true;
     chrome.runtime.sendMessage({ action: "getStatus" }, currentStatus => {
         if (chrome.runtime.lastError) {
             console.error(chrome.runtime.lastError.message);
             togglePauseBtn.disabled = false; return;
         }
         chrome.runtime.sendMessage({ action: "togglePause", paused: !currentStatus.isPaused }, response => {
             if (chrome.runtime.lastError) console.error(chrome.runtime.lastError.message);
             else console.log("Toggle response:", response);
             refreshStatus();
             togglePauseBtn.disabled = false;
         });
     });
  });

  // --- Initial Load and Interval ---
  refreshStatus(); // Initial load
  if (refreshInterval) clearInterval(refreshInterval);
  refreshInterval = setInterval(refreshStatus, 1000); // Refresh UI every second

});