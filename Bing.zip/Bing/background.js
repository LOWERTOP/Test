// background.js
let usedWords = [];
let countdownSeconds = 0;
let countdownInterval = null;
let isPaused = true; // In-memory state, default true
let currentIntervalLevel = 3; // Default level (4-6 min), will be loaded from storage

// Define interval levels (min/max in seconds)
const intervalMappings = [
  { level: 0, min: 60, max: 180, label: "1-3 分钟" },   // 1-3 min
  { level: 1, min: 120, max: 240, label: "2-4 分钟" },  // 2-4 min
  { level: 2, min: 180, max: 300, label: "3-5 分钟" },  // 3-5 min
  { level: 3, min: 240, max: 360, label: "4-6 分钟" },  // 4-6 min (Default)
  { level: 4, min: 300, max: 420, label: "5-7 分钟" },  // 5-7 min
  { level: 5, min: 360, max: 480, label: "6-8 分钟" },  // 6-8 min
  { level: 6, min: 420, max: 540, label: "7-9 分钟" }   // 7-9 min
];

// --- Initialization & Storage Loading ---
async function initializeState() {
    try {
        const data = await chrome.storage.local.get(["isPaused", "usedWords", "intervalLevel"]);
        // Load pause state (default true if not found)
        isPaused = typeof data.isPaused === 'boolean' ? data.isPaused : true;
        // Load used words (default empty array)
        usedWords = data.usedWords || [];
        // Load interval level (default 3 if not found)
        currentIntervalLevel = typeof data.intervalLevel === 'number' ? data.intervalLevel : 3;
        // Ensure level is within bounds
        if (currentIntervalLevel < 0 || currentIntervalLevel >= intervalMappings.length) {
            currentIntervalLevel = 3; // Reset to default if invalid
            await chrome.storage.local.set({ intervalLevel: currentIntervalLevel });
        }
        console.log(`Initialized state: isPaused=${isPaused}, intervalLevel=${currentIntervalLevel}, usedWords=${usedWords.length}`);
        updateBadge(); // Update badge based on loaded state
    } catch (error) {
        console.error("Error initializing state from storage:", error);
        // Use defaults in case of storage error
        isPaused = true;
        usedWords = [];
        currentIntervalLevel = 3;
        updateBadge();
    }
}

// --- Core Functions ---

async function fetchWordList() {
  // (Keep the previous robust version of this function)
  const url = "https://raw.githubusercontent.com/first20hours/google-10000-english/master/20k.txt";
  try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const text = await res.text();
      return text.split('\n').map(w => w.trim()).filter(Boolean);
  } catch (error) {
      console.error("Failed to fetch word list:", error);
      return [];
  }
}

async function getNextWord() {
  // (Keep the previous robust version of this function)
  const wordList = await fetchWordList();
  if (wordList.length === 0) return null;
  if (usedWords.length >= wordList.length) usedWords = [];

  let word = "", attempts = 0, maxAttempts = wordList.length * 2;
  do {
    word = wordList[Math.floor(Math.random() * wordList.length)];
    attempts++;
    if (attempts > maxAttempts) break;
  } while (usedWords.includes(word));

  if (word && !usedWords.includes(word)) {
      usedWords.push(word);
      chrome.storage.local.set({ usedWords }); // Async save
  } else if (!word) {
      console.error("Failed to select a word."); return null;
  }
  return word;
}

// --- Badge Update (Bug Fix 1: Use in-memory vars primarily) ---
function updateBadge() {
    // Relies on global isPaused and countdownSeconds being correct
    // These are updated by initializeState, togglePause, scheduleNextSearch interval
    const text = isPaused ? "⏸" : (countdownSeconds > 0 ? countdownSeconds.toString() : "");
    const color = isPaused ? '#00a6ed' : '#00a6ed';
    chrome.action.setBadgeText({ text: text });
    chrome.action.setBadgeBackgroundColor({ color: color });
}

// --- Scheduling (Uses currentIntervalLevel) ---
function scheduleNextSearch() {
  if (isPaused) {
      console.log("Schedule attempt while paused. Aborting.");
      if (countdownInterval) clearInterval(countdownInterval); // Ensure interval is cleared if mistakenly called
      countdownInterval = null;
      countdownSeconds = 0;
      updateBadge(); // Reflect paused state
      return;
  }

  // Get delay based on the current level
  const mapping = intervalMappings.find(m => m.level === currentIntervalLevel) || intervalMappings[3]; // Fallback to default
  const minDelay = mapping.min;
  const maxDelay = mapping.max;
  const delayInSeconds = minDelay + Math.floor(Math.random() * (maxDelay - minDelay));

  console.log(`Scheduling next search in ${delayInSeconds} seconds (Level ${currentIntervalLevel}: ${mapping.label}).`);

  countdownSeconds = delayInSeconds; // Set initial countdown
  chrome.alarms.create("autoSearch", { delayInMinutes: delayInSeconds / 60 });

  if (countdownInterval) clearInterval(countdownInterval); // Clear previous interval
  countdownInterval = setInterval(() => {
    if (countdownSeconds > 0) {
      countdownSeconds--; // Decrement in-memory counter
      updateBadge(); // Update badge using in-memory value
    } else {
      console.log("Countdown reached zero in interval, clearing.");
      clearInterval(countdownInterval);
      countdownInterval = null;
      // The alarm should fire very close to this point to trigger the search.
      // updateBadge will be called again after the search/reschedule.
    }
  }, 1000);

  updateBadge(); // Update badge immediately when scheduled
}

// --- Search Trigger ---
async function triggerSearch(word = null, manual = false) {
    const performSearch = async (searchWord) => {
        if (!searchWord) {
            console.error("No word provided for search."); return;
        }
        console.log(`Triggering search for: ${searchWord} (Manual: ${manual})`);
        try {
            await chrome.tabs.create({
                url: `https://www.bing.com/search?q=${encodeURIComponent(searchWord)}&FORM=ANAB01&PC=U531`
            });
        } catch (error) {
            console.error("Error creating search tab:", error);
        }

        // If it was an *automatic* search and we are *not paused*, schedule the next one
        if (!manual && !isPaused) {
            scheduleNextSearch();
        }
    };

    if (manual) {
        const searchWord = word || await getNextWord();
        await performSearch(searchWord);
    } else {
        if (!isPaused) { // Check if paused *before* getting word
            const searchWord = await getNextWord();
            await performSearch(searchWord);
        } else {
            console.log("Automatic search trigger skipped because extension is paused.");
        }
    }
}

// --- Event Listeners ---

chrome.runtime.onInstalled.addListener(async (details) => {
  console.log(`Extension ${details.reason}. Initializing default state.`);
  isPaused = true; // Default paused
  countdownSeconds = 0;
  currentIntervalLevel = 3; // Default interval level
  if (countdownInterval) clearInterval(countdownInterval);
  countdownInterval = null;
  await chrome.alarms.clearAll();
  // Set defaults in storage *only if they don't exist* or on install/update
  // Keep existing intervalLevel if it's already set from previous version
  const currentStorage = await chrome.storage.local.get(["intervalLevel"]);
  const defaultSettings = {
      isPaused: true,
      countdownSeconds: 0,
      usedWords: [],
      intervalLevel: typeof currentStorage.intervalLevel === 'number' ? currentStorage.intervalLevel : 3 // Keep existing or set default
  };
  await chrome.storage.local.set(defaultSettings);
  console.log("Default state set in storage:", defaultSettings);
  await initializeState(); // Load the finalized state into memory variables
});

chrome.runtime.onStartup.addListener(() => {
  console.log("Browser started. Initializing state from storage.");
  // Force pause on startup IS REMOVED as per user wanting settings persistence.
  // We just load the state, including the last pause state and interval level.
  initializeState().then(() => {
      if (!isPaused) {
          // If the state loaded from storage is "running", restart the schedule
          console.log("Resuming schedule based on stored state.");
          scheduleNextSearch();
      } else {
          // Ensure countdown is 0 if loaded as paused
          countdownSeconds = 0;
          updateBadge();
      }
  });
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "autoSearch") {
    console.log("Alarm 'autoSearch' received.");
    // Re-check pause state from memory (which should be up-to-date via initializeState/togglePause)
    if (!isPaused) {
        await triggerSearch(null, false); // Automatic trigger
    } else {
        console.log("Alarm triggered but extension is paused. Search cancelled.");
        // Safety clear, although togglePause should handle this
        if(countdownInterval) clearInterval(countdownInterval);
        countdownInterval = null;
        countdownSeconds = 0;
        updateBadge();
    }
  }
});

// --- Message Handling (Updated) ---
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getStatus") {
    // Provide current status primarily from memory, confirming with storage if needed for robustness
    const mapping = intervalMappings.find(m => m.level === currentIntervalLevel) || intervalMappings[3];
    sendResponse({
        countdown: isPaused ? 0 : countdownSeconds,
        wordCount: usedWords.length,
        isPaused: isPaused,
        intervalLevel: currentIntervalLevel,
        intervalLabel: mapping.label
    });
    return false; // Synchronous response

  } else if (msg.action === "triggerImmediate") {
    triggerSearch(null, true) // Manual trigger
        .then(() => sendResponse({ status: "ok" }))
        .catch(err => { console.error("Error triggerImmediate:", err); sendResponse({ status: "error" }); });
    return true; // Async

  } else if (msg.action === "resetWords") {
    console.log("Resetting used words list.");
    usedWords = [];
    chrome.storage.local.set({ usedWords }, () => { sendResponse({ status: "reset" }); });
    return true; // Async

  } else if (msg.action === "manualSearch" && msg.word) {
    triggerSearch(msg.word, true) // Manual trigger
       .then(() => {
           // Bug Fix 2: Reset timer after manual search IF running
           if (!isPaused) {
               console.log("Manual search finished, rescheduling automatic search.");
               // Clear existing timer/alarm and start a new schedule
               if (countdownInterval) clearInterval(countdownInterval);
               countdownInterval = null;
               chrome.alarms.clearAll(); // Clear existing alarm
               scheduleNextSearch(); // Start new countdown
           }
           sendResponse({ status: "searched" });
       })
       .catch(err => { console.error("Error manualSearch:", err); sendResponse({ status: "error" }); });
    return true; // Async

  } else if (msg.action === "togglePause") {
    const newState = msg.paused;
    console.log(`Toggling pause state to: ${newState}`);
    isPaused = newState; // Update memory state
    chrome.storage.local.set({ isPaused: newState }, () => { // Save to storage
        if (newState) { // Pausing
            if (countdownInterval) clearInterval(countdownInterval);
            countdownInterval = null;
            chrome.alarms.clearAll();
            countdownSeconds = 0;
        } else { // Resuming
            scheduleNextSearch(); // Start scheduling immediately
        }
        updateBadge();
        sendResponse({ status: newState ? "paused" : "resumed" });
    });
    return true; // Async

  } else if (msg.action === "setIntervalLevel") {
    const newLevel = msg.level;
    if (typeof newLevel === 'number' && newLevel >= 0 && newLevel < intervalMappings.length) {
        console.log(`Setting interval level to ${newLevel}`);
        currentIntervalLevel = newLevel; // Update memory state
        chrome.storage.local.set({ intervalLevel: newLevel }, () => { // Save to storage
            // If currently running, immediately reschedule with the new interval
            if (!isPaused) {
                console.log("Rescheduling search with new interval.");
                if (countdownInterval) clearInterval(countdownInterval);
                countdownInterval = null;
                chrome.alarms.clearAll();
                scheduleNextSearch();
            }
            sendResponse({ status: "levelSet", newLevel: newLevel });
        });
    } else {
        console.error("Invalid interval level received:", newLevel);
        sendResponse({ status: "error", message: "Invalid level" });
    }
    return true; // Async
  }

  // If message not handled, return false or undefined
});

// --- Set Uninstall URL ---
try {
    chrome.runtime.setUninstallURL("https://github.com/LOWERTOP/Shadowrocket-First/issues/new?title=%E5%8F%91%E8%A1%A5%E5%8F%91%E8%A7%89%E5%95%8F%E9%A1%8C%E6%88%96%E5%BB%BA%E8%AE%AE&body=%E8%B0%81%E7%94%A8%E8%BF%87%EF%BC%8C%E8%B0%81%E7%9F%A5%E9%81%93%EF%BC%8C%E5%B0%B1%E6%98%AF%E7%9F%A5%E9%81%93%EF%BC%81%0A%0A%E8%AF%B7%E5%9C%A8%E6%AD%A4%E5%A4%84%E8%AE%B0%E5%BD%95%E4%BD%A0%E5%AF%B9%E6%8F%92%E4%BB%B6%E7%9A%84%E6%84%8F%E8%A7%81%E6%88%96%E9%97%AE%E9%A2%98%E3%80%82"); // Replace if needed
} catch (e) { console.warn("Could not set uninstall URL.", e); }

// --- Initial load ---
initializeState(); // Load state when the service worker starts