let usedWords = [];
let countdownSeconds = 0;
let countdownInterval = null;

async function fetchWordList() {
  const url = "https://raw.githubusercontent.com/first20hours/google-10000-english/master/20k.txt";
  const res = await fetch(url);
  const text = await res.text();
  return text.split('\n').map(w => w.trim()).filter(Boolean);
}

async function getNextWord() {
  const wordList = await fetchWordList();
  let word = "";
  do {
    word = wordList[Math.floor(Math.random() * wordList.length)];
  } while (usedWords.includes(word));
  usedWords.push(word);
  chrome.storage.local.set({ usedWords });
  return word;
}

function updateBadge() {
  chrome.action.setBadgeText({ text: countdownSeconds.toString() });
  chrome.action.setBadgeBackgroundColor({ color: '#0078d7' });
}

function startCountdown(seconds) {
  countdownSeconds = seconds;
  if (countdownInterval) clearInterval(countdownInterval);
  countdownInterval = setInterval(() => {
    if (countdownSeconds > 0) {
      countdownSeconds--;
      chrome.storage.local.set({ countdownSeconds });
      updateBadge();
    }
  }, 1000);
  chrome.storage.local.set({ countdownSeconds });
  updateBadge();
}

function scheduleAlarm() {
  const delay = 240 + Math.floor(Math.random() * 120); // 240~360秒
  chrome.alarms.create('randomSearch', { delayInMinutes: delay / 60 });
  startCountdown(delay);
}

async function triggerSearch(word = null) {
  const searchWord = word || await getNextWord();
  chrome.tabs.create({
    url: `https://www.bing.com/search?q=${encodeURIComponent(searchWord)}&FORM=ANAB01&PC=U531`
  });
  scheduleAlarm();
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ usedWords: [], countdownSeconds: 0 });
  scheduleAlarm();
});

chrome.runtime.onStartup.addListener(() => {
  scheduleAlarm();
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'randomSearch') {
    triggerSearch().catch(console.error);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "getStatus") {
    chrome.storage.local.get(["countdownSeconds", "usedWords"], data => {
      sendResponse({
        countdown: data.countdownSeconds || 0,
        wordCount: data.usedWords ? data.usedWords.length : 0
      });
    });
    return true;
  } else if (msg.action === "triggerImmediate") {
    triggerSearch().then(() => sendResponse({ status: "ok" }));
    return true;
  } else if (msg.action === "resetWords") {
    usedWords = [];
    chrome.storage.local.set({ usedWords });
    sendResponse({ status: "reset" });
  } else if (msg.action === "manualSearch" && msg.word) {
    triggerSearch(msg.word).then(() => sendResponse({ status: "searched" }));
    return true;
  }
});

chrome.runtime.setUninstallURL("https://github.com/LOWERTOP/Shadowrocket-First/issues/new?title=%E5%8F%91%E8%A1%A5%E5%8F%91%E8%A7%89%E5%95%8F%E9%A1%8C%E6%88%96%E5%BB%BA%E8%AE%AE&body=%E8%B0%81%E7%94%A8%E8%BF%87%EF%BC%8C%E8%B0%81%E7%9F%A5%E9%81%93%EF%BC%8C%E5%B0%B1%E6%98%AF%E7%9F%A5%E9%81%93%EF%BC%81%0A%0A%E8%AF%B7%E5%9C%A8%E6%AD%A4%E5%A4%84%E8%AE%B0%E5%BD%95%E4%BD%A0%E5%AF%B9%E6%8F%92%E4%BB%B6%E7%9A%84%E6%84%8F%E8%A7%81%E6%88%96%E9%97%AE%E9%A2%98%E3%80%82");
