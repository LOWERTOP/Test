function formatSeconds(sec) {
  return `${sec} 秒`;
}

function updateDisplay() {
  chrome.runtime.sendMessage({ action: "getStatus" }, (response) => {
    document.getElementById("wordCount").innerText = response.wordCount;
    document.getElementById("nextSearch").innerText = formatSeconds(response.countdown);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setInterval(updateDisplay, 1000);
  updateDisplay();

  document.getElementById("searchNowBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "triggerImmediate" }, (response) => {
      console.log(response.status);
    });
  });

  document.getElementById("resetBtn").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "resetWords" }, (response) => {
      updateDisplay();
    });
  });

  const manualInput = document.getElementById("manualInput");
  const manualSearchBtn = document.getElementById("manualSearchBtn");

  manualSearchBtn.addEventListener("click", () => {
    const word = manualInput.value.trim();
    if (word) {
      chrome.runtime.sendMessage({ action: "manualSearch", word }, (response) => {
        console.log("manual search", response.status);
      });
    }
  });

  manualInput.addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
      manualSearchBtn.click();
    }
  });
});